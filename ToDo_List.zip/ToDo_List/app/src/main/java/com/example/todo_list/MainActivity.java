package com.example.todo_list;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.commons.io.*;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> items;
    ArrayAdapter<String> itemAdapter;
    ListView lvItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvItems = (ListView) findViewById(R.id.lvItems);
        items = new ArrayList<String>();
        readItems();
        itemAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,items);
        lvItems.setAdapter(itemAdapter);
        setupListViewListener();
    }
    public void addTodoItem(View view){
        EditText editText = (EditText) findViewById(R.id.etNewItem);
        itemAdapter.add(editText.getText().toString());
        saveItems();
    }
    public void setupListViewListener(){
        lvItems.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long rowId) {
                        items.remove(position);
                        itemAdapter.notifyDataSetChanged();
                        saveItems();
                        return true;
                    }
                }
        );
    }
    public void readItems(){
        File files = getFilesDir();
        File todoFile = new File(files,"todo.txt");
        try {
            items = new ArrayList<String>(FileUtils.readLines(todoFile));
        } catch (Exception e) {
            items = new ArrayList<String>();
            e.printStackTrace();
        }
    }
    public void saveItems(){
        File files = getFilesDir();
        File todoFile = new File(files,"todo.txt");
        try {
            FileUtils.writeLines(todoFile,items);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}